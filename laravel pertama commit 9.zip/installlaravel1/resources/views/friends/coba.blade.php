@extends('layouts.app')

@section('title', 'cobaaaaa')

@section('content')
    Urutan ke - {{ $ke }}
@endsection