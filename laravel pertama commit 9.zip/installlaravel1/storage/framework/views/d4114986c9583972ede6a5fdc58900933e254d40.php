<?php $__env->startSection('title', 'cobaaaaa'); ?>

<?php $__env->startSection('content'); ?>
<div class ="card">
    <div class ="card-body">
        <h3>nama teman : <?php echo e($friend['nama']); ?></h3>
        <h3>no telp teman : <?php echo e($friend['no_telp']); ?></h3>
        <h3>alamat teman : <?php echo e($friend['alamat']); ?></h3>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\installlaravel1\resources\views/friends/show.blade.php ENDPATH**/ ?>